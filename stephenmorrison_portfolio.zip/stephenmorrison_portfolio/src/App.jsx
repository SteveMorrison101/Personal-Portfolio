import React, { useState } from 'react';
import './global.css';
import './App.css';
import MenuImage from './assets/images/Menu.png';
import MovieReviewsImage from './assets/images/MovieReviews.png';
import DogAppImage from './assets/images/DogApp.png';
import NLArtCoImage from './assets/images/NLArtCo.png';

function App() {
  const [filter, setFilter] = useState('all');
  const [expandedProject, setExpandedProject] = useState(null);

  const projects = [
    {
      id: 1,
      title: 'A Python Menu',
      description: 'An interactive Python Menu that runs five different programs.',
      details: 'A python menu that runs programs to generate employee travel claim, the fizzbizz coding problem, a TechTitans membership card, a maintenance schedule for XYZ Company, and a password strength evaluator.',
      tech: 'python',
      image: MenuImage,
      repo: 'https://github.com/SteveMorrison101/A-Python-Menu.git',
    },
    {
      id: 2,
      title: 'Movie Rating Website',
      description: 'A Javascript-based movie review website',
      details: 'An interactive movie rating website that retrieves movie rating data from a .json file. All movie ratings in the database can be displayed. There are buttons to display the ratings for the top 3 movies, oldest movie, and newest movie in the database.',
      tech: 'javascript, html, css',
      image: MovieReviewsImage,
      repo: 'https://github.com/SteveMorrison101/Movie-Rating-Website.git',
    },
    {
      id: 3,
      title: 'Dog Image Gallery App',
      description: 'A React app that gives the user 1-100 pictures of a selected dog breed.',
      details: 'A React application that uses the Dog CEO API to allow the user to select a dog breed and specify how many pictures of the breed they want to be displayed (1-100). This app uses responsive design to enhance user experience, a dropdown breed selection menu, image quantity input, and implements hover effects on the dog pictures.',
      tech: 'javascript, css',
      image: DogAppImage,
      repo: 'https://github.com/SteveMorrison101/Dog-Image-Gallery-App.git',
    },
    {
      id: 4,
      title: 'Newfound Art Co Website',
      description: 'A responsive Javascript website',
      details: 'Created as a React application, this website was created for Newfound Art Co, a business operating out of Gander, Newfoundland. This website includes a Homepage, Product page, Store page, and checkout page.',
      tech: 'javascript, html',
      image: NLArtCoImage,
      repo: 'https://github.com/defford/ArtStoreProject',
    },
  ];

  const filteredProjects = projects.filter(
    (project) => filter === 'all' || project.tech.split(', ').includes(filter)
  );

  return (
    <div className="outer-box">
      <div className="inner-box">
        <header role="banner">
          <nav aria-label="Main Navigation" className="main-nav">
            <h1 className="site-name">Stephen Morrison</h1>
            <ul className="nav-links">
              <li><a href="#about">About</a></li>
              <li><a href="#projects">Projects</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </nav>
        </header>

        <main id="home">
          <section id="about" className="about-section">
            <h2>About Me</h2>
            <p>
              Hello! I’m Stephen Morrison, a 27-year-old Process Engineer who graduated from Memorial University of Newfoundland in 2021. Since then, 
              I’ve worked in the mining industry in Newfoundland while expanding my skills in software development.
            </p>
            <p>
            I’m currently a Software Development student at Keyin College with experience in Python, HTML, CSS, and building JavaScript applications, 
            incorporating modern frameworks like React into my projects to create dynamic and efficient applications.
            </p>
            <p>
            Outside of work and studies, I love hiking, mountain biking, weightlifting, and playing drums. In my downtime, 
            I like to relax hanging out with my cat, Ollie, and playing video games.
            </p>
          </section>

          <section id="projects" className="projects-section">
            <h2>Featured Projects</h2>
            <div className="project-filter">
              <label htmlFor="filter-select">Filter by Language:</label>
              <select
                id="filter-select"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              >
                <option value="all">All</option>
                <option value="css">CSS</option>
                <option value="javascript">JavaScript</option>
                <option value="html">HTML</option>
                <option value="python">Python</option>
              </select>
            </div>

            <div className="project-grid">
              {filteredProjects.map((project) => (
                <article
                  key={project.id}
                  className={`project-card ${expandedProject === project.id ? 'expanded' : ''}`}
                  data-tech={project.tech}
                >
                  <figure>
                    <img src={project.image} alt={`${project.title} screenshot`} />
                    <figcaption>{project.title}</figcaption>
                  </figure>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  {expandedProject === project.id && (
                    <div className="project-details">
                      <p>{project.details}</p>
                      <a href={project.repo} target="_blank" rel="noopener noreferrer">
                        View GitHub Repo
                      </a>
                    </div>
                  )}
                  <button
                    onClick={() =>
                      setExpandedProject(expandedProject === project.id ? null : project.id)
                    }
                  >
                    {expandedProject === project.id ? 'Hide Details' : 'Show More Details'}
                  </button>
                </article>
              ))}
            </div>
          </section>

          <section id="contact" className="contact-section">
            <h2>Get in Touch</h2>
            <form id="contact-form" onSubmit={(e) => e.preventDefault()}>
              <label htmlFor="name-input">Name:</label>
              <input type="text" id="name-input" required />

              <label htmlFor="email-input">Email:</label>
              <input type="email" id="email-input" required />

              <label htmlFor="message-textarea">Message:</label>
              <textarea id="message-textarea" required></textarea>

              <button type="submit">Send Message</button>
            </form>
          </section>
        </main>

        <footer>
          <p>© {new Date().getFullYear()} Stephen Morrison. All Rights Reserved.</p>
          <nav>
            <ul>
              <li><a href="https://www.linkedin.com/in/stephen-morrison-477893268/">LinkedIn</a></li>
              <li><a href="https://github.com/SteveMorrison101">GitHub</a></li>
            </ul>
          </nav>
        </footer>
      </div>
    </div>
  );
}

export default App;

































